#!/bin/bash

function for_each_async() {
    local f="${1}"
    local xs="${@:2}"
    local x
    for x in ${xs}
    do
        (${f} ${x} && :) &
    done
}

function souffle_kafka() {

    local EXE=${1}
    local KAFKA_HOST=${2:-"localhost:9092"}
    local VERBOSE=${3:-}

    local STRATUM_NAMES="$(${EXE} -Xcustom.print-metadata=true)"

    sleep 1s
    local ID="$(date +%s)_$(basename ${EXE} | sed 's/\./_/g')"

    local ARGS

    if [ "${VERBOSE}" == "--verbose" ]
    then
      echo "Deleting topics if they exist..."
      ARGS+=" -Xcustom.disable-stdout=false "
      ARGS+=" -Xcustom.disable-stderr=false "
    fi
    ARGS=""
    ARGS+=" -Xmetadata.broker.list=${KAFKA_HOST} "
    ARGS+=" -Xcustom.create-topics=false "
    ARGS+=" -Xcustom.run-program=false "
    ARGS+=" -Xcustom.delete-topics=true "
    ARGS+=" -Xcustom.unique-id=${ID} "
    ${EXE} ${ARGS}
    sleep 1s

    ARGS=""
    if [ "${VERBOSE}" == "--verbose" ]
    then
      echo "Creating topics..."
      ARGS+=" -Xcustom.disable-stdout=false "
      ARGS+=" -Xcustom.disable-stderr=false "
    fi
    ARGS+=" -Xmetadata.broker.list=${KAFKA_HOST} "
    ARGS+=" -Xcustom.create-topics=true "
    ARGS+=" -Xcustom.run-program=false "
    ARGS+=" -Xcustom.delete-topics=false "
    ARGS+=" -Xcustom.unique-id=${ID} "
    ${EXE} ${ARGS}

    if [ "${VERBOSE}" == "--verbose" ]
    then
      echo "Running program..."
      ARGS+=" -Xcustom.disable-stdout=false "
      ARGS+=" -Xcustom.disable-stderr=false "
    fi
    local ARGS=""
    ARGS+=" -Xmetadata.broker.list=${KAFKA_HOST} "
    ARGS+=" -Xcustom.create-topics=false "
    ARGS+=" -Xcustom.run-program=true "
    ARGS+=" -Xcustom.delete-topics=false "
    ARGS+=" -Xcustom.unique-id=${ID} "
    for_each_async "${EXE} ${ARGS} -i" -2 -3 ${STRATUM_NAMES}
    wait

}

function main() {
  souffle_kafka ${@}
}

main ${@}