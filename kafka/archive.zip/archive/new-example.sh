#!/bin/bash

set -oue -x pipefail

function for_each() {
    local f="${1}"
    local xs="${@:2}"
    local x
    for x in ${xs}
    do
        ${f} ${x}
    done
}

function for_each_async() {
    local f="${1}"
    local xs="${@:2}"
    local x
    for x in ${xs}
    do
        (echo "Begin '${f} ${x}'" && \
        ${f} ${x} && \
        echo "End '${f} ${x}'") &
    done
}

function ensure_autoreconf_is_called() {
    local CWD="${1}"
    local AUTORECONF_FLAGS="${2}"
    cd "${CWD}"
    autoreconf "${AUTORECONF_FLAGS}"
    cd -
}

function ensure_autoconf_project_is_built() {
    local CWD="${1}"
    local CONFIGURE_FLAGS="${2:-}"
    local JOBS=$(nproc || sysctl -n hw.ncpu || echo 2)
    local MAKE_FLAGS="-j${JOBS}"
    cd "${CWD}"
    ./configure ${CONFIGURE_FLAGS}
    make ${MAKE_FLAGS}
    cd -
}

function ensure_autoconf_project_is_installed() {
    local CWD="${1}"
    local CONFIGURE_FLAGS="${2:-}"
    ensure_autoconf_project_is_built "${CWD}" "${CONFIGURE_FLAGS}"
    cd "${CWD}"
    sudo make install
    sudo ldconfig
    cd -
}

function ensure_docker_compose_is_up() {
    local CWD="${1}"
    cd "${CWD}"
    sudo docker-compose up -d
    cd -
}

function ensure_docker_compose_is_down() {
    local CWD="${1}"
    cd "${CWD}"
    sudo docker-compose down
    cd -
}

function ensure_github_repo_is_cloned() {
    local CWD="${1}"
    local GITHUB_REPO="${2}"
    if [ ! -e "${CWD}/${GITHUB_REPO}" ]
    then
        git clone --recurse-submodules https://github.com/${GITHUB_REPO}.git "${CWD}/${GITHUB_REPO}"
    fi
}

function ensure_github_repo_is_updated() {
    local CWD="${1}"
    local GITHUB_REPO="${2}"
    cd "${CWD}/${GITHUB_REPO}"
    git submodule update --init --recursive
    cd -
}

function ensure_github_repo_is_cloned_and_updated() {
    local CWD="${1}"
    local GITHUB_REPO="${2}"
    ensure_github_repo_is_cloned "${CWD}" "${GITHUB_REPO}"
    ensure_github_repo_is_updated "${CWD}" "${GITHUB_REPO}"
}

function ensure_file_is_downloaded() {
    local CWD="${1}"
    local URL="${2}"
    ensure_directory_exists "${CWD}"
    if [ ! -e "${CWD}/$(basename "${URL}")" ]
    then
        cd "${CWD}"
        curl -O "${URL}"
        cd -
    fi
}

function ensure_tarball_is_unzipped() {
    local DIRNAME="$(dirname ${1})"
    local BASENAME="$(basename ${1})"
    if [ ! -e "${DIRNAME}/${BASENAME%.*}" ]
    then
        cd "${DIRNAME}"
        tar -xzf "${BASENAME}"
        cd -
    fi
}

function ensure_tarball_is_downloaded_and_unzipped() {
    local CWD="${1}"
    local URL="${2}"
    ensure_file_is_downloaded "${CWD}" "${URL}"
    ensure_tarball_is_unzipped "${CWD}/$(basename ${URL})"
}

function ensure_bootstrap_is_called() {
    local CWD="${1}"
    cd "${CWD}"
    ./bootstrap
    cd -
}

function ensure_directory_exists() {
    local DIRECTORY="${1}"
    mkdir -p "${DIRECTORY}"
}

function ensure_file_is_moved() {
    local FROM="${1}"
    local TO="${2}"
    if [ ! -e "${TO}" ]
    then
        ensure_directory_exists "$(dirname "${TO}")"
        mv "${FROM}" "${TO}"
    fi
}

function ensure_file_is_copied() {
    local FROM="${1}"
    local TO="${2}"
    if [ ! -e "${TO}" ]
    then
        ensure_directory_exists "$(dirname "${TO}")"
        cp -r "${FROM}" "${TO}"
    fi
}

function ensure_apt_package_installed() {
    local PACKAGE="${1}"
    if [ ! $(which "${PACKAGE}") ]
    then
        sudo apt-get install -y "${PACKAGE}"
    fi
}

function ensure_librdkafka_is_installed() {
    local CWD="${1}"
    local GITHUB_REPO="edenhill/librdkafka"
    if [ ! -e "/usr/local/lib/librdkafka.a" ]
    then
        ensure_github_repo_is_cloned "${CWD}" "${GITHUB_REPO}"
        ensure_autoconf_project_is_installed "${CWD}/${GITHUB_REPO}" "--install-deps"
    fi
}

function ensure_kafkacat_is_installed() {
    ensure_apt_package_installed kafkacat
}

function ensure_apache_kafka_is_installed() {
    local CWD="${1}"
    local KAFKA_PATH="${2}"
    local APACHE_KAFKA_URL="http://mirror.vorboss.net/apache/kafka/2.3.1/kafka_2.12-2.3.1.tgz"
    if [ ! -e "${KAFKA_PATH}" ]
    then
        ensure_tarball_is_downloaded_and_unzipped "${CWD}" "${APACHE_KAFKA_URL}"
        ensure_file_is_moved "${CWD}/kafka_2.12-2.3.1" "${KAFKA_PATH}"
    fi
}

function ensure_souffle_is_built_for_kafka() {
    local CWD="${1}"
    ensure_bootstrap_is_called "${CWD}"
    ensure_autoconf_project_is_built "${CWD}" "--enable-kafka --enable-debug --disable-libz --disable-sqlite"
}

function ensure_souffle_program_is_built() {
    local EXE="${1}"
    local FILE="${2}"
    local ARGS="${3}"
    local DIRNAME="$(dirname ${FILE})"
    local BASENAME="$(basename ${FILE})"
    local NAME="${BASENAME%%.*}"
    local COMMAND=""
    COMMAND+="${EXE}"
    COMMAND+=" -D${DIRNAME} "
    COMMAND+=" -F${DIRNAME}/facts "
    COMMAND+=" -o${DIRNAME}/${NAME} "
    COMMAND+=" -r${DIRNAME}/${NAME}.html "
    COMMAND+=" ${ARGS} "
    COMMAND+=" ${FILE} "
    if [ ! -e "${DIRNAME}/${NAME}" ]
    then
        cd "${DIRNAME}"
        # show transformed ram
        ${COMMAND} --show=transformed-ram
        # show global config
        ${COMMAND} --show=global-config
        # echo the command
        echo
        echo "${COMMAND}"
        echo
        # run souffle
        ${COMMAND}
        cd -
    fi
}

function ensure_kafka_depencencies_are_installed() {
    local CWD="${1}"
    local KAFKA_PATH="${2}"
    ensure_librdkafka_is_installed "${CWD}"
    ensure_kafkacat_is_installed "${CWD}"
    ensure_apache_kafka_is_installed "${CWD}" "${KAFKA_PATH}"
}

function ensure_souffle_test_case_is_built() {
    local SOUFFLE_ROOT="${1}"
    local TEST_CASE="${2}"
    local SOUFFLE_ARGS="${3:-}"
    local TESTSUITE_DIR="${SOUFFLE_ROOT}/tests/testsuite.dir"
    local TEST_CASE_FROM="${SOUFFLE_ROOT}/tests/${TEST_CASE}"
    local TEST_CASE_TO="${TESTSUITE_DIR}/${TEST_CASE}"
    ensure_file_is_copied "${TEST_CASE_FROM}" "${TEST_CASE_TO}"
    ensure_souffle_program_is_built "${SOUFFLE_ROOT}/src/souffle" "${TEST_CASE_TO}/$(basename "${TEST_CASE_TO}").dl" "${SOUFFLE_ARGS}"
}

function ensure_test_case_passes() {
    local TEST_CASE="${1}"
    local SOUFFLE_ARGS="${2:-}"
    local EXE_ARGS="${3:-}"
    local TESTSUITE_DIR="${PWD}/tests/testsuite.dir"
    local TEST_CASE_ROOT="${TESTSUITE_DIR}/${TEST_CASE}"
    local EXE="${TEST_CASE_ROOT}/$(basename ${TEST_CASE})"
    # remove the testsuite directotry
    rm -rf "${TESTSUITE_DIR}"
    # ensure that test case is built
    ensure_souffle_test_case_is_built "${PWD}" "${TEST_CASE}" "${SOUFFLE_ARGS}"
    # record the expected output files
    cat "${TEST_CASE_ROOT}"/*.csv | sort > "${TEST_CASE_ROOT}"/expected.txt
    # remove the expected output files, these are overridden by actual outputs on execution
    rm -rf "${TEST_CASE_ROOT}"/*.csv
    # run the program
    ${EXE} ${EXE_ARGS}
    # record the actual output files
    cat "${TEST_CASE_ROOT}"/*.csv | sort > "${TEST_CASE_ROOT}"/actual.txt
    # diff the actual vs expected output
    if [ "$(diff "${TEST_CASE_ROOT}"/actual.txt "${TEST_CASE_ROOT}"/expected.txt)" ]
    then
        echo
        echo "ERROR"
        echo " TEST_CASE='${TEST_CASE}'"
        echo " SOUFFLE_ARGS='${SOUFFLE_ARGS}'"
        echo " EXE_ARGS='${EXE_ARGS}'"
        echo " ACTUAL='"
        cat "${TEST_CASE_ROOT}"/actual.txt
        echo " '"
        echo " EXPECTED='"
        cat "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo " DIFF='"
        diff "${TEST_CASE_ROOT}"/actual.txt "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo
        read -p "Continue?"
    else
        echo
        echo "SUCCESS"
        echo " TEST_CASE='${TEST_CASE}'"
        echo " SOUFFLE_ARGS='${SOUFFLE_ARGS}'"
        echo " EXE_ARGS='${EXE_ARGS}'"
        echo " ACTUAL='"
        cat "${TEST_CASE_ROOT}"/actual.txt
        echo " '"
        echo " EXPECTED='"
        cat "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo " DIFF='"
        diff "${TEST_CASE_ROOT}"/actual.txt "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo
    fi
    mv "${TESTSUITE_DIR}" "${TESTSUITE_DIR}.$(date +%s)"
}

function ensure_kafka_test_case_passes() {
    local KAFKA_HOST="${1}"
    local TEST_CASE="${2}"
    local SOUFFLE_ARGS="${3:-}"
    local EXE_ARGS="${4:-}"
    local TESTSUITE_DIR="${PWD}/tests/testsuite.dir"
    local TEST_CASE_ROOT="${TESTSUITE_DIR}/${TEST_CASE}"
    local EXE="${TEST_CASE_ROOT}/$(basename ${TEST_CASE})"
    # remove the testsuite directotry
    rm -rf "${TESTSUITE_DIR}"
    # ensure that test case is built
    ensure_souffle_test_case_is_built "${PWD}" "${TEST_CASE}" "${SOUFFLE_ARGS}"
    # record the expected output files
    cat "${TEST_CASE_ROOT}"/*.csv | sort > "${TEST_CASE_ROOT}"/expected.txt
    # remove the expected output files, these are overridden by actual outputs on execution
    rm -rf "${TEST_CASE_ROOT}"/*.csv
    # run the program on the kafka cluster
    chmod +x ${PWD}/kafka/souffle-kafka.sh
    ${PWD}/kafka/souffle-kafka.sh "${EXE}" "${KAFKA_HOST}" --verbose
    # record the actual output files
    cat "${TEST_CASE_ROOT}"/*.csv | sort > "${TEST_CASE_ROOT}"/actual.txt
    # diff the actual vs expected output
    if [ "$(diff "${TEST_CASE_ROOT}"/actual.txt "${TEST_CASE_ROOT}"/expected.txt)" ]
    then
        echo
        echo "ERROR"
        echo " TEST_CASE='${TEST_CASE}'"
        echo " SOUFFLE_ARGS='${SOUFFLE_ARGS}'"
        echo " EXE_ARGS='${EXE_ARGS}'"
        echo " ACTUAL='"
        cat "${TEST_CASE_ROOT}"/actual.txt
        echo " '"
        echo " EXPECTED='"
        cat "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo " DIFF='"
        diff "${TEST_CASE_ROOT}"/actual.txt "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo
        read -p "Continue?"
    else
        echo
        echo "SUCCESS"
        echo " TEST_CASE='${TEST_CASE}'"
        echo " SOUFFLE_ARGS='${SOUFFLE_ARGS}'"
        echo " EXE_ARGS='${EXE_ARGS}'"
        echo " ACTUAL='"
        cat "${TEST_CASE_ROOT}"/actual.txt
        echo " '"
        echo " EXPECTED='"
        cat "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo " DIFF='"
        diff "${TEST_CASE_ROOT}"/actual.txt "${TEST_CASE_ROOT}"/expected.txt
        echo " '"
        echo
    fi
    mv "${TESTSUITE_DIR}" "${TESTSUITE_DIR}.$(date +%s)"
}

function ensure_test_cases_pass() {
    local TEST_CASE="${1}"

    # run tests for no -e

   # normal seminaive evaluation
   ensure_test_case_passes "${TEST_CASE}"
   # generalized seminaive evaluation
   ensure_test_case_passes "${TEST_CASE}" -Xuse-general
   # generalized seminaive evaluation with output relations written to files inside fixpoint loop
   ensure_test_case_passes "${TEST_CASE}" -Xuse-general -Xuse-general-producers

   # run tests for -Xuse-engine-file

   # normal seminaive evaluation with intermediate results written to and read from files
   ensure_test_case_passes "${TEST_CASE}" "-Xuse-engine-file"
   # generalized seminaive evaluation with intermediate results written to and read from files outside of fixpoint loop
   ensure_test_case_passes "${TEST_CASE}" "-Xuse-engine-file -Xuse-general"
   # generalized seminaive evaluation with intermediate results read from files outside of fixpoint loop and written to files inside fixpoint loop
   ensure_test_case_passes "${TEST_CASE}" "-Xuse-engine-file -Xuse-general -Xuse-general-producers"

   # run tests for -Xuse-engine-kafka

   # set variables for kafka
   local KAFKA_HOST="localhost:9092"
   local KAFKA_DOCKER_PATH="${PWD}/kafka"

   # start the kafka broker
   ensure_docker_compose_is_down "${KAFKA_DOCKER_PATH}"
   ensure_docker_compose_is_up "${KAFKA_DOCKER_PATH}"

   # normal seminaive evaluation with intermediate results produced to and consumed from kafka topics
   ensure_kafka_test_case_passes "${KAFKA_HOST}" "${TEST_CASE}" "-Xuse-engine-kafka"

   # generalized seminaive evaluation with intermediate results produced to and consumed from kafka topics outside of fixpoint loop
   ensure_kafka_test_case_passes "${KAFKA_HOST}" "${TEST_CASE}" "-Xuse-engine-kafka -Xuse-general"
   # generalized seminaive evaluation with intermediate results consumed from kafka topics outside of fixpoint loop and produced to kafka topics inside of fixpoint loop
   ensure_kafka_test_case_passes "${KAFKA_HOST}" "${TEST_CASE}" "-Xuse-engine-kafka -Xuse-general -Xuse-general-producers"
   # generalized seminaive evaluation with intermediate results produced to and consumed from kafka topics inside of fixpoint loop
   ensure_kafka_test_case_passes "${KAFKA_HOST}" "${TEST_CASE}" "-Xuse-engine-kafka -Xuse-general -Xuse-general-producers -Xuse-general-consumers"
}

function ensure_testsuite_case_passes() {
  local TEST_NUMBER="${1}"
  if [ -e "tests/testsuite" ]
  then
    cd tests
    ./testsuite "${TEST_NUMBER}"
    cd -
  fi
}

function ensure_testsuite_passes() {
    local JOBS=$(nproc || sysctl -n hw.ncpu || echo 2)
    local SOUFFLE_CATEGORY="FastEvaluation"
    local SC=""
    SC+=" -j${JOBS} "
    local SOUFFLE_CONFS=""
    SOUFFLE_CONFS+="${SC}"
    SOUFFLE_CONFS+=",${SC} -c"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-engine-file"
    SOUFFLE_CONFS+=",${SC} -Xuse-general"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-general"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-engine-file -Xuse-general"
    SOUFFLE_CONFS+=",${SC} -Xuse-general -Xuse-general-producers"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-general -Xuse-general-producers"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-engine-file -Xuse-general -Xuse-general-producers"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-engine-kafka"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-engine-kafka -Xuse-general"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-engine-kafka -Xuse-general -Xuse-general-producers"
    SOUFFLE_CONFS+=",${SC} -c -Xuse-engine-kafka -Xuse-general -Xuse-general-producers -Xuse-general-consumers"
    export SOUFFLE_CATEGORY="${SOUFFLE_CATEGORY}"
    export SOUFFLE_CONFS="${SOUFFLE_CONFS}"
    make clean || :
    ./bootstrap
    SOUFFLE_CATEGORY=${SOUFFLE_CATEGORY} SOUFFLE_CONFS=${SOUFFLE_CONFS} ./configure --enable-kafka --enable-debug --disable-libz --disable-sqlite
    make -j${JOBS}
    TESTSUITEFLAGS="-j${JOBS}" make check -j${JOBS}
}

function ensure_sudo_permissions() {
    sudo echo
}

function ensure_kafka_tests_pass() {
  local TEST_CASE="${1}"
  local TEST_NUMBER="${2}"

    # ensure we have sudo permissions
    ensure_sudo_permissions

    # ensure that we are in the root directory of the souffle project
    [[ $(basename ${PWD}) != souffle ]] && exit 1

    # ensure that the testsuite directory does does not exist yet
    local TESTSUITE_DIR="${PWD}/tests/testsuite.dir"

    # make a temp directory for dependencies
    local TMP_PATH="/tmp/souffle"

    # use a home directory for kafka
    local KAFKA_PATH="${HOME}/.kafka"

    # set the path to use the kafka scripts
    export PATH="${KAFKA_PATH}/bin:${PATH}"

    # ensure dependencies are installed
    ensure_kafka_depencencies_are_installed "${TMP_PATH}" "${KAFKA_PATH}"

    # ensure that souffle is built for kafka
    ensure_souffle_is_built_for_kafka "${PWD}"

    # ensure that some particular test passes under all configurations
    ensure_test_cases_pass "${TEST_CASE}"

    # ensure that some particular testsuite case passes
    ensure_testsuite_case_passes "${TEST_NUMBER}"

    # run the testsuite
    ensure_testsuite_passes

    # stop the kafka broker
    ensure_docker_compose_is_down "${KAFKA_DOCKER_PATH}"
}

function main() {

    ensure_kafka_tests_pass "evaluation/arithm" 16

    exit 0
}


main ${@:-}



